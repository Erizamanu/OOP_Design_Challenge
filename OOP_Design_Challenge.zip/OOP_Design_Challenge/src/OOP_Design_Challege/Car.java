package OOP_Design_Challege;

// Car class inherits from Vehicle superclass and implements drivable interface
public class Car extends Vehicle implements Drivable {
	private int numDoors;

	public Car(String make, String model, int numDoors) {
		super(make, model);
		this.numDoors = numDoors;
	}

	// Interface implementation
	@Override
	public void drive() {
		System.out.println("Car is driving at " + speed + " mph.");

	}

	// Method overriding
	@Override
	public void startEngine() {
		System.out.println("Car engine started.");
	}

	// Stamp coupling - passing an object/struct with data
	public void updateVehicleInfo(VehicleInfo info) {
		make = info.make;
		model = info.model;
		speed = info.speed;
		System.out.println("Vehicle info updated via stamp coupling.");
	}
}
