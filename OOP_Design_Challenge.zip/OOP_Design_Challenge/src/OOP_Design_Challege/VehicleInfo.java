package OOP_Design_Challege;

// Java struct for Stamp coupling
public class VehicleInfo {
	public String make;
	public String model;
	public int speed;
	
	public VehicleInfo(String make, String model, int speed) {
		this.make = make;
		this.model = model;
		this.speed = speed;
	}
}
