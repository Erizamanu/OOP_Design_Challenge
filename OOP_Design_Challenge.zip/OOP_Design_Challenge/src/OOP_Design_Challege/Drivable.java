package OOP_Design_Challege;

// Interface for implementation
public interface Drivable {
	public void drive();
}
