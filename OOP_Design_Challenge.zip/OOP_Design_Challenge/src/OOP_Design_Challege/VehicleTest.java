package OOP_Design_Challege;

public class VehicleTest {
	public static void main(String[] args) {
		// Generate instances of motorcycle and car
		Car myCar = new Car("BMW", "440i", 4);
		Motorcycle myBike = new Motorcycle("Marley-Davidson", "Street 750");
		
		// Test inheritance and method overriding
		myCar.startEngine();
		myCar.startEngine();
		
		// Test polymorphism and method overloading
		myCar.accelerate(10);
		myCar.accelerate(5, 3);
		
		// Interface implementation
		myCar.drive();
		
		// Data coupling
		myBike.updateSpeed(45);
		
		// Stamp coupling
		VehicleInfo info = new VehicleInfo("Jeep", "Wrangler", 2);
		myCar.updateVehicleInfo(info);
	}
}
