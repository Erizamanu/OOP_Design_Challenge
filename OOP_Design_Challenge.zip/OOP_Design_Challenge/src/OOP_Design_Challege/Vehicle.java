package OOP_Design_Challege;

// Abstract class to demonstrate inheritance
public abstract class Vehicle {
	protected String make;
	protected String model;
	protected int speed;
	
	public Vehicle(String make, String model) {
		this.make = make;
		this.model = model;
		speed = 0;
	}
	
	// Abstract method to be overwritten in subclasses
	public abstract void startEngine();
	
	// Data coupling - Method is passed primitive data
	public void updateSpeed(int speed) {
		this.speed = speed;
	}
	
	// Method overloading - two accelerate methods with different input parameters
	public void accelerate(int increment) {
		speed += increment;
		System.out.println("Accelerated by " + increment + " mph. New speed: " + speed);
	}
	
	public void accelerate(int increment, int duration) {
		speed += increment * duration;
		System.out.println("Accelerated by " + (increment * duration) + 
				" mph over " + duration + " seconds. New speed: " + speed);
	}
}
