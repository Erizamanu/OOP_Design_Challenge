package OOP_Design_Challege;

public class Motorcycle extends Vehicle {
	public Motorcycle(String make, String model) {
		super(make, model);
	}

	// method overriding for polymorphism
	@Override
	public void startEngine() {
		System.out.println("Motorcycle engine started with a roar!");
	}
}
